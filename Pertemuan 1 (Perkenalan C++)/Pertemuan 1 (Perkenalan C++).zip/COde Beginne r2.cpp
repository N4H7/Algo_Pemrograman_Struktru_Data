#include <iostream>
using namespace std;

int main()
{
	cout <<"Hello my name is Jonathan and I'm curently studying in IBI Kesatuan"
	<< endl << "Ofcourse it is not easy to study Information Tech"
	<< endl << "But I will give it my best till the end"
	<< endl << "Because this is my own choise and I want to master this thing";
	return 0;
}
	
