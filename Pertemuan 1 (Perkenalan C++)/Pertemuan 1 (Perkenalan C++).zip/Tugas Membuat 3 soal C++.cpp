#include <iostream>
using namespace std;

int main()
{
	char operasi;
	cout << "Pilih Operasi (+ - * /): ";
	cin>>operasi;
	
	if (operasi == '+') {
	int a,b;
	cout << "Penjumlahan" "\n" <<endl;
	cout << "Masukan Bilangan A: ";
	cin>>a;
	cout << "Masukan Bilangan B: ";
	cin>>b;	
	cout << "Hasil Penjumlahan A dan B Adalah: " << a + b <<endl;
	}
	
	else if (operasi == '-') {
	int a,b;
	cout << "Pengurangan" "\n" <<endl;
	cout << "Masukan Bilangan A: ";
	cin>>a;
	cout << "Masukan Bilangan B: ";
	cin>>b;	
	cout << "Hasil Pengurangan A dan B Adalah: " << a - b <<endl;
	}
	
	else if (operasi == '*') {
	int a,b;
	cout << "Perkalian" "\n" <<endl;
	cout << "Masukan Bilangan A: ";
	cin>>a;
	cout << "Masukan Bilangan B: ";
	cin>>b;	
	cout << "Hasil Perkalian A dan B Adalah: " << a * b <<endl;
	}
	
	else if (operasi == '/') {
	float a,b;
	cout << "Pembagian" "\n" <<endl;
	cout << "Masukan Bilangan A: ";
	cin>>a;
	cout << "Masukan Bilangan B: ";
	cin>>b;	
	cout << "Hasil Pembagian A dan B Adalah: " << a / b <<endl;
	}
	
	else {
	cout << "Maaf Akang Teteh Operasi Ini Belum Tersedia! :)" <<endl;
	}
	
	char operasi2;
	cout <<endl;
	cout << "Pilih Operasi 2 (+ - * /): ";
	cin>>operasi;
	
	if (operasi == '+') {
	int a,b;
	cout << "Penjumlahan" "\n" <<endl;
	cout << "Masukan Bilangan A: ";
	cin>>a;
	cout << "Masukan Bilangan B: ";
	cin>>b;	
	cout << "Hasil Penjumlahan A dan B Adalah: " << a + b <<endl;
	}
	
	else if (operasi == '-') {
	int a,b;
	cout << "Pengurangan" "\n" <<endl;
	cout << "Masukan Bilangan A: ";
	cin>>a;
	cout << "Masukan Bilangan B: ";
	cin>>b;	
	cout << "Hasil Pengurangan A dan B Adalah: " << a - b <<endl;
	}
	
	else if (operasi == '*') {
	int a,b;
	cout << "Perkalian" "\n" <<endl;
	cout << "Masukan Bilangan A: ";
	cin>>a;
	cout << "Masukan Bilangan B: ";
	cin>>b;	
	cout << "Hasil Perkalian A dan B Adalah: " << a * b <<endl;
	}
	
	else if (operasi == '/') {
	float a,b;
	cout << "Pembagian" "\n" <<endl;
	cout << "Masukan Bilangan A: ";
	cin>>a;
	cout << "Masukan Bilangan B: ";
	cin>>b;	
	cout << "Hasil Pembagian A dan B Adalah: " << a / b <<endl;
	}
	
	else {
	cout << "Maaf Akang Teteh Operasi Ini Belum Tersedia! :)" <<endl;
	}
	
	char operasi3;
	cout <<endl;
	cout << "Pilih Operasi 3 (+ - * /): ";
	cin>>operasi;
	
	if (operasi == '+') {
	int a,b;
	cout << "Penjumlahan" "\n" <<endl;
	cout << "Masukan Bilangan A: ";
	cin>>a;
	cout << "Masukan Bilangan B: ";
	cin>>b;	
	cout << "Hasil Penjumlahan A dan B Adalah: " << a + b <<endl;
	}
	
	else if (operasi == '-') {
	int a,b;
	cout << "Pengurangan" "\n" <<endl;
	cout << "Masukan Bilangan A: ";
	cin>>a;
	cout << "Masukan Bilangan B: ";
	cin>>b;	
	cout << "Hasil Pengurangan A dan B Adalah: " << a - b <<endl;
	}
	
	else if (operasi == '*') {
	int a,b;
	cout << "Perkalian" "\n" <<endl;
	cout << "Masukan Bilangan A: ";
	cin>>a;
	cout << "Masukan Bilangan B: ";
	cin>>b;	
	cout << "Hasil Perkalian A dan B Adalah: " << a * b <<endl;
	}
	
	else if (operasi == '/') {
	float a,b;
	cout << "Pembagian" "\n" <<endl;
	cout << "Masukan Bilangan A: ";
	cin>>a;
	cout << "Masukan Bilangan B: ";
	cin>>b;	
	cout << "Hasil Pembagian A dan B Adalah: " << a / b <<endl;
	}
	
	else {
	cout << "Maaf Akang Teteh Operasi Ini Belum Tersedia! :)" <<endl;
	}
	
	char operasi4;
	cout <<endl;
	cout << "Pilih Operasi 4 (+ - * /): ";
	cin>>operasi;
	
	if (operasi == '+') {
	int a,b;
	cout << "Penjumlahan" "\n" <<endl;
	cout << "Masukan Bilangan A: ";
	cin>>a;
	cout << "Masukan Bilangan B: ";
	cin>>b;	
	cout << "Hasil Penjumlahan A dan B Adalah: " << a + b <<endl;
	}
	
	else if (operasi == '-') {
	int a,b;
	cout << "Pengurangan" "\n" <<endl;
	cout << "Masukan Bilangan A: ";
	cin>>a;
	cout << "Masukan Bilangan B: ";
	cin>>b;	
	cout << "Hasil Pengurangan A dan B Adalah: " << a - b <<endl;
	}
	
	else if (operasi == '*') {
	int a,b;
	cout << "Perkalian" "\n" <<endl;
	cout << "Masukan Bilangan A: ";
	cin>>a;
	cout << "Masukan Bilangan B: ";
	cin>>b;	
	cout << "Hasil Perkalian A dan B Adalah: " << a * b <<endl;
	}
	
	else if (operasi == '/') {
	float a,b;
	cout << "Pembagian" "\n" <<endl;
	cout << "Masukan Bilangan A: ";
	cin>>a;
	cout << "Masukan Bilangan B: ";
	cin>>b;	
	cout << "Hasil Pembagian A dan B Adalah: " << a / b <<endl;
	}
	
	else {
	cout << "Maaf Akang Teteh Operasi Ini Belum Tersedia! :)" <<endl;
	}
	
	return 0;
}
