#include <iostream>
using namespace std;

int main(){
	int number;
	
	cout << "Enter an integer: ";
	cin >> number;
	
	cout << "You entered " << number;
	return 0;	
}
