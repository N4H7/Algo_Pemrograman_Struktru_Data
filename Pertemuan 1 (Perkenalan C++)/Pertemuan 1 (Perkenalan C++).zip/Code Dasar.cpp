#include <iostream>
using namespace std;

int main(){

 cout << "Welcome To The IBI Kesatuan Campus";
 
 return 0;
}
